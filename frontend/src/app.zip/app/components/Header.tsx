// src/app/components/Header.tsx
import "./Header.css";
import { useState, useEffect } from "react";
import logo from "@/assets/logo.png?version=2";
import { GoogleLogin, CredentialResponse } from "@react-oauth/google";
import { useAuth } from "../context/AuthContext";

export function Header() {
  const [isMobile, setIsMobile] = useState(false);
  const { user, token, loginWithToken, logout } = useAuth();

  useEffect(() => {
    const handleResize = () => setIsMobile(window.innerWidth < 640);
    handleResize();
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  const handleSuccess = (credentialResponse: CredentialResponse) => {
    if (!credentialResponse?.credential) return;
    loginWithToken(credentialResponse.credential);

    // not blocking: notify backend if you want
    fetch("http://localhost:8000/__noop", { method: "GET" }).catch(() => {});
  };

  const handleError = () => {
    console.log("Login Failed");
  };

  return (
    <header className="header">
      <div className="header-container">
        <div className="header-left">
          <div className="header-title-wrapper">
            <h1 className="header-title">Sejais Santo</h1>
            <p className="header-subtitle">Porque Deus é Santo</p>
          </div>
          <img src={logo} alt="São Carlo Acutis" className="header-logo" />
        </div>

        <div className="header-right">
          {user ? (
            <div className="header-user">
              {user.picture ? (
                <img src={user.picture} alt={user.name} className="user-avatar" />
              ) : (
                <div className="user-avatar user-avatar-fallback">
                  {user.name?.charAt(0).toUpperCase() ?? "U"}
                </div>
              )}

              <button className="logout-button" onClick={logout} aria-label="Sair">
                Sair
              </button>
            </div>
          ) : (
            <GoogleLogin
              onSuccess={handleSuccess}
              onError={handleError}
              size={isMobile ? "medium" : "large"}
              shape="pill"
              text="signin"
            />
          )}
        </div>
      </div>
    </header>
  );
}