import { Calendar } from "lucide-react";
import "./GospelCard.css";

export function GospelCard() {
  return (
    <div className="gospel-card">
      {/* Date Selector */}
      <div className="gospel-date-selector">
        <Calendar className="gospel-calendar-icon" />
        <select className="gospel-select">
          <option>Evangelho de Hoje</option>
        </select>
      </div>

      {/* Gospel Preview */}
      <div className="gospel-preview">
        <div className="gospel-content">
          <iframe
            frameborder="0"
            width="100%"
            height="90%"
            src="https://evangeli.net/evangelho-family/widget/web"
          ></iframe>
        </div>
      </div>
    </div>
  );
}
