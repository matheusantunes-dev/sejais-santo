// src/app/context/AuthContext.tsx
import React, { createContext, useContext, useEffect, useState } from "react";
import { jwtDecode } from "jwt-decode";

interface GoogleJwtPayload {
  sub?: string;
  email?: string;
  name?: string;
  picture?: string;
  [k: string]: any;
}

export interface AuthUser {
  id: string;
  name: string;
  email: string;
  picture?: string;
}

interface AuthContextValue {
  user: AuthUser | null;
  token: string | null;
  loginWithToken: (token: string) => void;
  logout: () => void;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({
  children,
}) => {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [token, setToken] = useState<string | null>(null);

  useEffect(() => {
    const raw = localStorage.getItem("sejais_user");
    const tk = localStorage.getItem("sejais_token");
    if (raw) {
      try {
        setUser(JSON.parse(raw));
      } catch {
        localStorage.removeItem("sejais_user");
      }
    }
    if (tk) setToken(tk);
  }, []);

  const loginWithToken = (tkn: string) => {
    try {
      const decoded = jwtDecode<GoogleJwtPayload>(tkn);
      // normalized
      const id = decoded.sub ?? "";
      const email = decoded.email ?? "";
      const name = decoded.name ?? "Usuário";
      const picture = decoded.picture ?? "";

      if (!id || !email) {
        console.warn("Token decoded but missing id/email");
      }

      const u: AuthUser = {
        id,
        name,
        email,
        picture,
      };

      setUser(u);
      setToken(tkn);
      localStorage.setItem("sejais_user", JSON.stringify(u));
      localStorage.setItem("sejais_token", tkn);
      console.log("JWT DECODED:", decoded);
    } catch (err) {
      console.error("Failed to decode token", err);
    }
  };

  const logout = () => {
    setUser(null);
    setToken(null);
    localStorage.removeItem("sejais_user");
    localStorage.removeItem("sejais_token");
  };

  return (
    <AuthContext.Provider value={{ user, token, loginWithToken, logout }}>
      {children}
    </AuthContext.Provider>
  );
};